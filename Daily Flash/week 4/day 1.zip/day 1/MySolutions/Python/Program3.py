

print("\n  -----  Kilometer to meter conversion ---- \n")

num=int(input("\nEnter distance in km : "))

print("\n",num,"km is equal to ", num*1000,"m\n")



'''
Output :

(base) mayuri@mayuri-PC:~/C2WT/Daily Flash/week 4/day 1/MySolutions/Python$ python3 Program3.py 

  -----  Kilometer to meter conversion ---- 


Enter distance in km : 2

 2 km is equal to  2000 m



'''
