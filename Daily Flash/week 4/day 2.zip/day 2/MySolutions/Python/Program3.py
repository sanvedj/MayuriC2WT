print("\nFeet to cm")

feet=float(input("\nEnter distance in feet : "))

print("\nEquivalent distance of",feet," ft in cm is ",feet*30," cm \n\n")



'''
Output :

(base) mayuri@mayuri-PC:~/C2WT/Daily Flash/week 4/day 2/MySolutions/Python$ python3 Program3.py

Feet to cm

Enter distance in feet : 6

Equivalent distance of 6.0  ft in cm is  180.0  cm 



'''
