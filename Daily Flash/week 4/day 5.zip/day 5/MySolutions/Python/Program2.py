from array import *

print("\nDecimal to hexadecimal ")
num=int(input("\nEnter a decimal number : "))

print("\nHexadecimal number :",hex(num)[2:])
print()

'''
Output :


(base) mayuri@mayuri-PC:~/C2WT/Daily Flash/week 4/day 5/MySolutions/Python$ python3 Program2.py

Decimal to hexadecimal 

Enter a decimal number : 43

Hexadecimal number : 2b



'''
