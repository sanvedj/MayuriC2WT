'''
Problem Statement : 

Program 5: Pattern.

'''

print()

for i in range(4):
	for j in range(0,i+1):
		print("  *",end=" ")
	print()	

print()


'''
Output : 

(base) mayuri@mayuri-PC:~/C2WT/Daily Flash/week 2/day 3/MySolutions/Python$ python3 Program5.py

  * 
  *   * 
  *   *   * 
  *   *   *   * 


'''
