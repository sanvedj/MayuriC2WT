/*

Program 1. Write a program which add new node in singly linear linked list at first position.

Function Prototype :

int InsertFirst( struct node **Head, int no );


Input linked list : |10|->|20|->|30|->|40|->|50|->|60|->|70|
Input data element : 21
Output linked list : |21|->|10|->|20|->|30|->|40|->|50|->|60|->|70| 

*/


